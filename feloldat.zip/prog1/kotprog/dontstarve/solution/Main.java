package prog1.kotprog.dontstarve.solution;

public class Main {
    
}
