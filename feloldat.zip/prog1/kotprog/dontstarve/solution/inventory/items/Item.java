package prog1.kotprog.dontstarve.solution.inventory.items;

public class Item extends AbstractItem {
    public Item(ItemType type, int amount) {
        super(type, amount);
    }    
}
