/**
 * Az inventory-ban előforduló itemek / tárgyak leírására szolgáló osztályokat tartalmazó package.
 */
package prog1.kotprog.dontstarve.solution.inventory.items;
