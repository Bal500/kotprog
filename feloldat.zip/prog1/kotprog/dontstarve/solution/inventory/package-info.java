/**
 * A karakterek inventory-jához kapcsolódó osztályokat tartalmazó package.
 */
package prog1.kotprog.dontstarve.solution.inventory;
