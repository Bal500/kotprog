/**
 * A program során előforduló kivételeket tartalmazó package.
 */
package prog1.kotprog.dontstarve.solution.exceptions;
